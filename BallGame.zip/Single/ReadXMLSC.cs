﻿using UnityEngine;
using System.Collections;
using System.Xml;
using System.IO;
using System.Collections.Generic;
using System.Text;
// ReadXMLSC 通过类名.getInstance().readxml调用 （传入xml路径，返回list容器）
// update(传入当前关卡等级，传入xml路径)
public class ReadXMLSC:SingleTonBaseSC<ReadXMLSC>{


	//改为传入TextAsset
	string getXMLAddress(TextAsset textAsset){
		string content = textAsset.text;

		StringBuilder sbu = new StringBuilder ();
		sbu.Append (Application.persistentDataPath + "/" + textAsset.name);

		string Path = sbu.ToString ();

		if (!File.Exists(Path)) {
			Debug.Log ("not find but I can get");
			File.WriteAllText (Path, content);
		}
		return Path;
	}
	//获取当前xml文档的所以关卡信息
	public List<LevelSC> readXML(TextAsset textAsset){
		XmlDocument doc = new XmlDocument ();

		doc.Load (getXMLAddress(textAsset));

		XmlElement root = doc.DocumentElement;
	
		XmlNodeList rootChilds = root.ChildNodes;
		List<LevelSC> levelGroup = new List<LevelSC> ();
	//Debug.Log ("anaylis xml start");
		foreach (XmlNode rootChild in rootChilds) {
			XmlElement Childcell = (XmlElement)rootChild;
			int _number = int.Parse (Childcell.GetElementsByTagName ("number") [0].InnerText);

			bool _lock = (Childcell.GetElementsByTagName ("lock") [0].InnerText)=="false" ? false:true;

			int _star = int.Parse (Childcell.GetElementsByTagName ("star") [0].InnerText);
			int _time = int.Parse (Childcell.GetElementsByTagName ("time") [0].InnerText);
			int _target = int.Parse (Childcell.GetElementsByTagName ("target") [0].InnerText);
			LevelSC level = new LevelSC (_number, _lock, _star, _time, _target);
			levelGroup.Add (level);
		}
	//	Debug.Log ("anaylis xml end");
		return levelGroup;
	}

	//通过后，更新信息 (解锁下一关 )
	//在AddScore类中（吃完宝石达到要求后）调用该方法
	//在UI_GameTimeSC中调用该方法
	public void updateXML(LevelSC currentLevel){

		XmlDocument doc = new XmlDocument ();
		StringBuilder sbu = new StringBuilder ();

		sbu.Append(Application.persistentDataPath + "/" + "LevelXmlFile");
		doc.Load (sbu.ToString());

		//Debug.Log (sbu.ToString ());
		XmlElement root = doc.DocumentElement;
		XmlNodeList childs = root.ChildNodes;

		//更新获得的当前星数，初始值为3星
		childs [currentLevel._number - 1] ["star"].InnerText = currentLevel._star.ToString ();

		Debug.Log ("update"+currentLevel._star);

		if (currentLevel._number == childs.Count) {
			Debug.Log ("您已超神,请等待我们下一个版本- -||");
			return;
		} else {
			//解锁下一关
			Debug.Log ("解锁下一关");
			// child为0起始  number为1为起始下标
			childs [currentLevel._number] ["lock"].InnerText ="true";
		}

		//保存的是沙河路径里的文件，并非是自己写的xml文件
		doc.Save(sbu.ToString());
	}

}
