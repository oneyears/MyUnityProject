﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
//加载反射命名空间
/// <summary>
///对关卡XML进行管理
/// GetConfig是获取所有关卡xml信息
/// GetCurrentLevel是获得当前关卡的xml信息
/// 
/// SelectLevelView 调用该了类
/// </summary>
public class LevelXMLCtrlSC : SingleTonBaseSC<LevelXMLCtrlSC> {

	private List<LevelSC> _levelGourp;
	public LevelSC _currentLevel;  //在SelectLevelView类获取当前关卡，所以应该在Select按钮触发后使用？
	public List<LevelSC> GetConfig(){
		//使用反射获取SelectLevelView类的方法

		//为何使用不了Type
		//Type t = typeof(SelectLevelView);
		_levelGourp = new List<LevelSC>();
		if (_levelGourp.Count == 0) {
			Debug.Log ("GetConfig~");
			TextAsset LevelTest = Resources.Load ("LevelXmlFile") as TextAsset;
			if (LevelTest == null) {
				Debug.Log ("not find file");
				return _levelGourp;
			}
			_levelGourp = ReadXMLSC.GetInstance ().readXML (LevelTest);
		}
		//每次read都会add新的数组，所以不能再词读取了
		//以及调用过一次，（第二次选择关卡的时候调用，解锁关卡需要调用）
		if (_levelGourp.Count != 0) {
			Debug.Log ("GetConfig调用两次以上~");
			TextAsset LevelTest = Resources.Load ("LevelXmlFile") as TextAsset;
			Debug.Log (LevelTest.text);
			_levelGourp = ReadXMLSC.GetInstance ().readXML (LevelTest);
		}

		return _levelGourp;
	}

}
