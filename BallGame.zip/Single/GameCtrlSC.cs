﻿using UnityEngine;
using System.Collections;

public class GameCtrlSC : SingleTonBaseSC<GameCtrlSC> {

	public void PauseGame(){
		Time.timeScale = 0;
	}

	public void ResumeGame(){
		Time.timeScale = 1;
	}

	//重新加载当前关卡
	public void NewGame(){
		ResumeGame ();
		Application.LoadLevel (Application.loadedLevel);
		//UI_WinCtrlSC.GetInstance ().CloseWindow ("Prefabs/GameWin/GameOverPanel", false);
	}

	public void gameOver(){
		
		GameObject windowUI = UI_WinCtrlSC.GetInstance ().OpenWindow ("Prefabs/GameWin/GameOverPanel",GameObject.Find("CenterContainer").transform);
		Debug.Log (windowUI);
		windowUI.GetComponent<GameResultCtrlSC> ().SetWinSprire (false);	
		PauseGame ();
	}
		
	public void returnMenuScene(){
		//返回菜单栏，记得把当前暂停状态设置为播放状态，否则下一次进入场景时还是暂停的状态
		ResumeGame ();
		Application.LoadLevel ("MenuScene");
	}

	public void gameWin(){

		GameObject windowUI = UI_WinCtrlSC.GetInstance ().OpenWindow ("Prefabs/GameWin/GameOverPanel",GameObject.Find("CenterContainer").transform);
		windowUI.GetComponent<GameResultCtrlSC> ().SetWinSprire (true);
		PauseGame ();
	}

}
