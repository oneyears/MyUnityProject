﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
/// <summary>
/// 窗口UI管理器  not use
/// </summary>
public class UI_WinCtrlSC : SingleTonBaseSC<UI_WinCtrlSC> {
	//该字典可以保存多久？，什么时候会重置？
	public Dictionary<string,GameObject> _windowCache = new Dictionary<string, GameObject>();
	GameObject windowUI = null;

	public GameObject OpenWindow (string windowPath, Transform parentPos){
	
		if (_windowCache.ContainsKey (windowPath)) {
			Debug.Log ("open win");
			//打开窗口
			//Debug.Log (_windowCache [windowPath]);
			windowUI = _windowCache [windowPath];
			if (windowUI == null) {
				createNewWIn(windowPath,parentPos);
				Debug.Log ("not find this path,but I can Add");
			}
			windowUI.SetActive (true);
		} else {
			//加载场景
			createNewWIn (windowPath, parentPos);
			windowUI.SetActive (true);
			_windowCache.Add (windowPath, windowUI);
		}
		return windowUI;
	}

	GameObject createNewWIn(string windowPath, Transform parentPos){
		GameObject WindowPrefab = Resources.Load (windowPath) as GameObject;
		windowUI = GameObject.Instantiate (WindowPrefab);
		windowUI.transform.parent = parentPos;
		windowUI.transform.localPosition = Vector3.zero;
		windowUI.transform.localScale = Vector3.one;
		windowUI.transform.localRotation = Quaternion.Euler (Vector3.zero);
		return windowUI;
	}
		
	//如过未先打开窗口，（没有加载uiSprite，没有缓存），则会报空引用错误
	public void CloseWindow(string windowPath,bool remove = false){

		if (_windowCache.ContainsKey (windowPath)) {
			Debug.Log (windowPath);

			windowUI = _windowCache [windowPath];
			Debug.Log (windowUI);
			if (windowUI == null) {
				Debug.Log ("not found window UI");
				return;
			}
			windowUI.SetActive (false);
		} else {
			Debug.Log ("not find in Cache");
			if (remove) {
				GameObject.Destroy (windowUI);
				_windowCache.Remove (windowPath);
			} 
			windowUI.SetActive (false);
		}
	}

}
