﻿	using UnityEngine;
using System.Collections;

public class PlayCtrlSC : MonoBehaviour {

	public EasyJoystick _joyStick;
	Rigidbody _rig;

	public float _force = 10f;

	//AddScore类与其建立关系
	public delegate void AddScoreDelegate ();
	public static event AddScoreDelegate _addScore;

	void Start () {
		if (_joyStick == null) {
			_joyStick = GameObject.FindObjectOfType<EasyJoystick> ();
		}
		if (_rig == null) {
			_rig = GetComponent<Rigidbody> ();
		}
	}
	
	void Update () {
		playControl ();
	}

	void playControl(){
	
		if (_joyStick.JoystickAxis.x != 0 || _joyStick.JoystickAxis.y != 0) {
			float xdir = _joyStick.JoystickAxis.x;
			float zdir = _joyStick.JoystickAxis.y;

			_rig.AddForce (new Vector3 (xdir, 0, zdir).normalized * _force * Time.deltaTime,ForceMode.VelocityChange);
		}

	}

	void OnTriggerEnter(Collider target) {
		Debug.Log ("enter");
		if (target.CompareTag("Gem")) {
			Debug.Log (_addScore);
			if (_addScore != null) {
				_addScore ();
			}
			Destroy (target.gameObject);
		}
	}
}
