﻿using UnityEngine;
using System.Collections;

public class CameraCtrlSC : MonoBehaviour {

	public Transform _targetPos;
	public float _ypos = 6f;
	public float _zpos = 10f;
	public float _dumping = 5f;

	void Start () {
		Init ();
	}
	
	void Update () {

	}

	void LateUpdate(){
		follow ();
	}

	void Init(){
		if (_targetPos == null) {
			_targetPos = GameObject.FindWithTag ("Player").transform;
		}
	}

	void follow(){
		Vector3 newPosition = _targetPos.position + new Vector3 (0, _ypos, -_zpos);
		transform.position = newPosition;
		transform.LookAt (_targetPos);
	}

}
