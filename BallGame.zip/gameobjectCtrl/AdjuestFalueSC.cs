﻿using UnityEngine;
using System.Collections;

public class AdjuestFalueSC : MonoBehaviour {

	void OnTriggerEnter(Collider target){
		if (target.gameObject.name.Equals (SpriteNameSC.PlayerName)) {
			GameCtrlSC.GetInstance ().gameOver ();
		}
	}
}
