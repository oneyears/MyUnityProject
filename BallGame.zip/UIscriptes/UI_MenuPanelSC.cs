﻿using UnityEngine;
using System.Collections;

public class UI_MenuPanelSC : UI_WinBaseCtrlSC {

	public GameObject _MenuBtn;
	public GameObject _MenuPanel;

	public GameObject _WinPanel;

	UIPanel menuPanel;
	bool IsShow{get;set;}
	public float _showSpeed = 2f;

	protected override void OnStart ()
	{
		Init ();
	}

	protected override void OnUpdate ()
	{
		playControl ();
	}

	void Init(){
		if (_MenuBtn == null) {
			_MenuBtn = GameObject.FindWithTag ("MenuBtn");
		}

		if (_MenuPanel == null) {
			_MenuPanel = GameObject.FindWithTag ("MenuPanel");
		}

		if (_WinPanel == null) {
			_WinPanel = GameObject.FindWithTag ("WinPanel");
		}

		menuPanel = _MenuPanel.GetComponent<UIPanel> ();
		UIEventListener.Get (_MenuBtn).onClick += show;
	}

	void show(GameObject go){
		IsShow = !IsShow;
	}

	void playHide(){
			float value = 1 / _showSpeed * Time.deltaTime;
			menuPanel.alpha -= value;
	}
	void playShow(){
			float value = 1 / _showSpeed * Time.deltaTime;
			menuPanel.alpha += value;
	}
	void playControl(){
		if (IsShow && menuPanel.alpha < 1) {
			playShow ();
			if (menuPanel.alpha >= 1) {
				Debug.Log ("open");
				OpenWin ();
			}
		}
		if (!IsShow && menuPanel.alpha > 0) {
			playHide ();
			if (menuPanel.alpha <= 0) {
				Debug.Log ("hide");
				closeWin ();
			}
		}
	}

	void closeWin(){
		_WinPanel.SetActive (false);
	}
	void OpenWin(){
		_WinPanel.SetActive (true);
	}
}
