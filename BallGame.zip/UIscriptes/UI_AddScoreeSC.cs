﻿using UnityEngine;
using System.Collections;
using System.Text;
using System.Collections.Generic;
/// <summary>
/// 对游戏场景的ScoreLabel进行加分
/// </summary>
public class UI_AddScoreeSC : UI_WinBaseCtrlSC {


	LevelSC _currentLevel;
	[SerializeField]
	UILabel _scoreLabel;

	int _currentGotScore;

	protected override void OnStart ()
	{
		base.OnStart ();
		Init ();
	}
	//根据当前关卡初始化Label
	void Init(){

		_currentLevel = LevelXMLCtrlSC.GetInstance ()._currentLevel;
		_scoreLabel = GetComponentInChildren<UILabel> ();
		//_currentGotScore = _currentLevel._targetScore;

		Debug.Log (_currentLevel._number);

		if (_scoreLabel == null) {
			_scoreLabel = GetComponentInChildren<UILabel> ();
		}
		Debug.Log (_scoreLabel);
		StringBuilder sbu = new StringBuilder ();
		sbu.Append (_currentGotScore.ToString ());
		sbu.Append ("/");
		sbu.Append (_currentLevel._targetScore.ToString ());
		_scoreLabel.text = sbu.ToString ();
		//注册加分事件
		PlayCtrlSC._addScore += addScore;

	}

	//碰撞到宝石Gem后执行加分方法
	void addScore(){
	//	Debug.Log ("开始加分");
		_currentGotScore++;
		StringBuilder sbu2 = new StringBuilder ();
		sbu2.Append (_currentGotScore.ToString ());
		sbu2.Append ("/");
		sbu2.Append (_currentLevel._targetScore.ToString ());
		_scoreLabel.text = sbu2.ToString ();

		Debug.Log (_currentLevel);
		//吃完宝石
		if (_currentGotScore >= _currentLevel._targetScore) {

			_currentLevel._star = 3;
			ReadXMLSC.GetInstance ().updateXML (_currentLevel);

			GameCtrlSC.GetInstance ().gameWin ();

		}
		//在时间内没吃完宝石 ,可在时间条写
//		if (_currentGotScore >= _currentLevel._targetScore / 2) {
//			GameCtrlSC.GetInstance ().gameWin ();
//			_currentLevel._star = 2;
//			ReadXMLSC.GetInstance ().updateXML (_currentLevel);
//		}
//		if(_currentGotScore>= 1 && _currentGotScore)

	}

	protected override void BeforeDestroy ()
	{
		base.BeforeDestroy ();
		PlayCtrlSC._addScore -= addScore ;
	}
}
