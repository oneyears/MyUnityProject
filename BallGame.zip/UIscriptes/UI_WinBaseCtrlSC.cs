﻿using UnityEngine;
using System.Collections;

public class UI_WinBaseCtrlSC : MonoBehaviour {




	void Awake(){
		OnAwake ();
	}

	void OnEnable(){
		AfterEnable ();
	}

	void Start () {
		OnStart ();
	}

	void Update () {
		OnUpdate ();
	}

	void OnDestroy(){
		BeforeDestroy ();
	}

	protected virtual void OnAwake (){
	}
	protected virtual void AfterEnable(){
	}
	protected virtual void OnStart(){
	}
	protected virtual void OnUpdate(){
	}
	protected virtual void BeforeDestroy(){
	}

}
