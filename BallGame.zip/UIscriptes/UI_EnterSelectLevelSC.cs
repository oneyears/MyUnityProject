﻿using UnityEngine;
using System.Collections;

public class UI_EnterSelectLevelSC :UI_WinBaseCtrlSC {


	protected override void OnStart ()
	{
		base.OnStart ();
		Init ();
	}

	protected override void OnUpdate ()
	{
		base.OnUpdate ();
	}

	void Init(){
		UIButton btn = GetComponentInChildren<UIButton> ();
		UIEventListener.Get (btn.gameObject).onClick = delegate(GameObject go) {
			Debug.Log("进入选择关卡场景");
			Application.LoadLevel("SelectLevelScene");

		};
	}

}
