﻿using UnityEngine;
using System.Collections;

public class UI_ProgressBarSC : UI_WinBaseCtrlSC {

	public UIProgressBar _progressBar;
	public float _moveTime = 4f;
	bool IsOver{ set; get;}

	protected override void OnStart ()
	{

		if(_progressBar == null)
			_progressBar = GetComponent<UIProgressBar> ();
		_progressBar.value = 0;
	}

	protected override void OnUpdate ()
	{
		progressGo ();
	}

	void progressGo(){
		if (_progressBar.value < 1) {
			_progressBar.value += 1/_moveTime  * Time.deltaTime;
			if (_progressBar.value >= 1)
				IsOver = true;
		} else {
			_progressBar.value = 0;
		}

		if (IsOver) {
			Debug.Log ("nextScene");
			IsOver = false;
			Application.LoadLevel ("MenuScene");
		}
	}
		
}
