﻿using UnityEngine;
using System.Collections;
/// <summary>
/// 游戏结束类，包含重新开始，或退回到菜单场景 ,通过获取子物体的按钮控制
/// </summary>
public class GameResultCtrlSC : UI_WinBaseCtrlSC {

	public UIButton [] _buttonGroup;
	[SerializeField]
	private UISprite _gameRusultSprite;

	protected override void OnStart ()
	{
		base.OnStart ();
		Init ();
	}

	protected override void OnUpdate ()
	{
		base.OnUpdate ();
	}

	void Init(){
		_buttonGroup = GetComponentsInChildren<UIButton> ();
		_gameRusultSprite = GetComponentInChildren<UISprite> ();
		Debug.Log (_gameRusultSprite.name);
		for (int index = 0; index < _buttonGroup.Length; index++) {
			//为何可以直接用 = delegate?
			UIEventListener.Get (_buttonGroup [index].gameObject).onClick = delegate(GameObject go) {
				findBtnAndGo(go);
			};
		}
	}

	void findBtnAndGo(GameObject go){
		switch (go.name) {
		case"menuBtn":
			GameCtrlSC.GetInstance ().returnMenuScene ();
			break;
		case"newGameBtn":
			GameCtrlSC.GetInstance ().NewGame ();
			UI_WinCtrlSC.GetInstance ().CloseWindow ("Prefabs/GameWin/GameOverPanel");
			break;
		default:
			break;
		}
	}

	public void SetWinSprire(bool win = false) {
		_gameRusultSprite = GetComponentInChildren<UISprite> ();
		Debug.Log (_gameRusultSprite);
		if (win) {
			_gameRusultSprite.spriteName = SpriteNameSC.WinIcon;
		} else {
			_gameRusultSprite.spriteName = SpriteNameSC.FailureIcon;
		}
	}

}
