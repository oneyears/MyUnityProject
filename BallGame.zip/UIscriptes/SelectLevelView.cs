﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
/// <summary>
/// 选择场景UI类，每次进入场景，调用，获取点击按钮的信息（是否进入游戏）
/// 读取XML 与LevelXMLCtrlSC相关联
/// </summary>
public class SelectLevelView : UI_WinBaseCtrlSC {


	LevelView[] _levelViewGroup;

	List<LevelSC> _levelGroup;

	//add :
	//首先默认设置关卡为1
	//CurrentLevel _selectLevel =  new CurrentLevel ();
	LevelSC _currentLevel;
	protected override void AfterEnable ()
	{
		base.AfterEnable ();
		Init ();
	}


	//读取XML 与LevelXMLCtrlSC
	void Init(){
		Debug.Log("select Level Game");

		_levelViewGroup = GetComponentsInChildren<LevelView> ();

		//从xml更新 _levelGroup
		if(_levelGroup == null)
		_levelGroup = LevelXMLCtrlSC.GetInstance ().GetConfig ();
		Debug.Log ("GetCofig?");

		//通过 _levelGroup 更新每个按钮
		for (int index = 0; index < _levelViewGroup.Length; index++) {

			//Debug.Log (_levelGroup [index]._lock);
	
			_levelViewGroup [index].setLock (_levelGroup [index]._lock);

			//设置星星的数量
			//Debug.Log (_levelGroup [index]._star);
			_levelViewGroup [index].setStarNumber (_levelGroup [index]._star);

			int levelNumberIndex = index;

			//给每个按钮添加点击事件
			_levelViewGroup [index].setLockButtonClick (delegate(GameObject go) {
				Debug.Log("Level"+levelNumberIndex+1);
				if(!_levelGroup[levelNumberIndex]._lock){
					//打开窗口
					UI_WinCtrlSC.GetInstance().OpenWindow("Prefabs/SelectLevelWin/selectWinTipPanel",GameObject.Find("CenterContainer").transform);
					//进行关卡xml管理TODO
				}else{
					Debug.Log("加载场景");

					LevelXMLCtrlSC.GetInstance()._currentLevel = _levelGroup[levelNumberIndex];
					//将当前关卡的信息放到 LevelXMLCtrlSC 里，通过调用单例把当前的场景调出来
		
					Application.LoadLevel("Level"+(levelNumberIndex+1));
				}
			});
		}
	}
}
