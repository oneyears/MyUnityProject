﻿using UnityEngine;
using System.Collections;

public class UI_backBtnSC : UI_WinBaseCtrlSC {

	public UIButton _backBtn;

	protected override void OnStart ()
	{
		_backBtn = GetComponent<UIButton> ();
	}
		
	protected override void OnUpdate ()
	{
		base.OnUpdate ();
	}

	void OnClick(){
		Debug.Log ("back");
		gameObject.transform.parent.parent.gameObject.SetActive (false);

	}
}
