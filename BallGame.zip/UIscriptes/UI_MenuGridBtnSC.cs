﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class UI_MenuGridBtnSC : UI_WinBaseCtrlSC {


	GameObject _currentWin;
	GameObject _preWin;
	[SerializeField]
	private int _winSize = 2;
	public GameObject [] _Wins;


	protected override void OnStart ()
	{
		GameObject _bagRetBtn = GameObject.Find ("bagbtn");
		GameObject _storeRetBtn = GameObject.Find ("storebtn");

		UIEventListener.Get (_bagRetBtn).onClick = closeWin;
		UIEventListener.Get (_storeRetBtn).onClick = closeWin; 
	}
		
	
	protected override void OnUpdate ()
	{
		base.OnUpdate ();
	}

	void closeWin(GameObject go){

		_currentWin = _Wins [int.Parse (go.tag)];
		if (_currentWin.activeInHierarchy) {
			_currentWin.SetActive (false);
		}
		else {
			_currentWin.SetActive (true);
			if (_preWin != null && _preWin.activeInHierarchy && _preWin != _currentWin ) {
				_preWin.SetActive (false);
			}

		}
		_preWin = _currentWin;
	}
}
