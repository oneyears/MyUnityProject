﻿using UnityEngine;
using System.Collections;

public class UILockBtn : UIButton {


}
