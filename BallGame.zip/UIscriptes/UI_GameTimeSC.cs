﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class UI_GameTimeSC : UI_WinBaseCtrlSC {

	public UIProgressBar _progressBar;

	public LevelSC _currentLevel;

	public float _moveTime = 10f;
	bool IsOver{ set; get;}

	protected override void OnStart ()
	{

		if(_progressBar == null)
			_progressBar = GetComponent<UIProgressBar> ();

		if (_currentLevel == null) {
			_currentLevel = LevelXMLCtrlSC.GetInstance ()._currentLevel;
		}

		_progressBar.value = 0;
		_moveTime = _currentLevel._time;
	}

	protected override void OnUpdate ()
	{
		progressGo ();
	}

	void progressGo(){
		if (_progressBar.value < 1) {
			_progressBar.value += 1/_moveTime  * Time.deltaTime;
			if (_progressBar.value >= 1)
				IsOver = true;
		} else {
			_progressBar.value = 0;
		}

		if (IsOver) {
			Debug.Log ("nextScene");
			IsOver = false;

			_currentLevel._star = 0;
			ReadXMLSC.GetInstance ().updateXML (_currentLevel);
			GameCtrlSC.GetInstance ().gameWin ();

		//	Application.LoadLevel ("Level"+(_currentLevel._number+1));
		//	GameCtrlSC.GetInstance ().gameOver ();
		}
	}

}
