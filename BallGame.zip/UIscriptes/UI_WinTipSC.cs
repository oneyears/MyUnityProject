﻿using UnityEngine;
using System.Collections;

public class UI_WinTipSC : UI_WinBaseCtrlSC {

	public float _hideTime = 1f;

	protected override void AfterEnable ()
	{
		base.AfterEnable ();
		Init ();
	}

	void Init(){
		StartCoroutine(HideTip(_hideTime));
	}
	//IEnumerator ?
	IEnumerator HideTip(float time) {
		yield return new WaitForSeconds (time);
		UI_WinCtrlSC.GetInstance ().CloseWindow ("Prefabs/SelectLevelWin/selectWinTipPanel",false);
	}
}
