﻿using UnityEngine;
using System.Collections;

public class UIStarSprite : UISprite {


}
