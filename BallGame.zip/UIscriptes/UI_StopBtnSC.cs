﻿using UnityEngine;
using System.Collections;

public class UI_StopBtnSC :UI_WinBaseCtrlSC{

	

	bool _toggle = false;
	protected override void OnStart ()
	{

	Init ();
	}
	void Init(){
		_toggle = false;
	}

	void OnClick(){

		if (!_toggle) {
			Debug.Log ("游戏暂停");
			GameCtrlSC.GetInstance ().PauseGame ();
		} else {
			Debug.Log ("继续游戏");
			GameCtrlSC.GetInstance ().ResumeGame ();
		}
		_toggle = !_toggle;
	}
}
