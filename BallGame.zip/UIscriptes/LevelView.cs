﻿using UnityEngine;
using System.Collections;

//一个锁的状态的类
public class LevelView : UI_WinBaseCtrlSC {
	[SerializeField]
	UILockBtn _lockBtn;
	[SerializeField]
	UIStarSprite [] _starGroup;
	bool _updateStarFlag = false;

	protected override void OnStart ()
	{
		base.OnStart ();
		Reset ();
	} 

	void Reset(){
		if (_lockBtn == null) {
			_lockBtn = GetComponentInChildren<UILockBtn> ();
		}
		if (_starGroup.Length == 0) {
			_starGroup = GetComponentsInChildren<UIStarSprite> ();
		}
		gameObject.addc
	}

	//改变按钮图片
	public void setLock(bool isLock){


		Debug.Log (_lockBtn.name);
		//normalSprite?
		_lockBtn.normalSprite = !isLock ? SpriteNameSC.lockTextureName : SpriteNameSC.unLockTextureName;
		_lockBtn.tweenTarget.GetComponent<UISprite> ().spriteName = _lockBtn.normalSprite;
	}

	//在游戏胜利后 改变星星图片  TODO
	public void setStarNumber(int number) {
		_starGroup = GetComponentsInChildren<UIStarSprite> ();
		Debug.Log (_starGroup.Length);
		Debug.Log ("setStart");
		for (int index = 0; index < number; index++) {
			Debug.Log ("setStart change");
			_starGroup [index].spriteName = SpriteNameSC.star_unLock;

		}
		Debug.Log ("number big");	
	}
	public void setLockButtonClick(UIEventListener.VoidDelegate clickCall) {
		UIEventListener.Get (_lockBtn.gameObject).onClick = clickCall;
	}


}
