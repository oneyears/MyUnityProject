﻿using UnityEngine;
using System.Collections;

public class SpriteNameSC {

	public static string PlayerName = "PlayCtrlSCSphere";

	public static string lockTextureName = "JiaHaoAnNiu";
	public static string unLockTextureName = "PuTongGongJi";

	public static string star_lock = "JinXingKuLong";
	public static string star_unLock = "JinXing_02";

	public static string WinIcon = "ZhanDouShengLi";
	public static string FailureIcon = "ZhanDouShiBai";




}
