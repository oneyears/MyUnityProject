﻿using UnityEngine;
using System.Collections;

public class LevelSC {
	public int _number;
	public bool _lock;
	public int _star;
	public int _time;
	public int _targetScore;
	public LevelSC(){
	}

	public LevelSC(int _number,bool _lock,int _star,int _time,int _target){
		this._number = _number;
		this._lock = _lock;
		this._star = _star;
		this._time = _time;
		this._targetScore = _target;
	}

}
