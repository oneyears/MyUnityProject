﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using UnityEngine.Networking;

/// <summary>
/// AB test.
/// 1.LoadFromMemory
/// 2.KiadFromFile
/// 3.WWW (基本用服务器存储) 最多使用
/// 4.WebRequest 官网说要用WebRequest代替WWW
/// </summary>



public class ABTest : MonoBehaviour {

	//第一种使用方式FromMemory:从内存中下载资源
	//第二种使用方式FromFile:从文件中加载资源使用 5.2版本需要压缩格式本地file: 加载
	//第三种使用方式WWW 下载资源使用
	//第四种使用方式WebRequest:从WebRequest下载资源使用          

	string path = "/Users/neworigin/Desktop/YoungAB/newprefab";
	string matPath = "/Users/neworigin/Desktop/YoungAB/mat01";


	string wwwMatPath = "file:///Users/neworigin/Desktop/YoungAB/mat01";
	string wwwPath = "file:///Users/neworigin/Desktop/YoungAB/newprefab";

	string path4 = "file:///Users/neworigin/Desktop/YoungAB/newprefab";

	string pathMat4 = "file:///Users/neworigin/Desktop/YoungAB/YoungAB";
	string pathMat44 = "file:///Users/neworigin/Desktop/YoungAB/";
		//newprefab"

	/*
	void Start(){
		StartCoroutine(FFFTest());
	}
	IEnumerator FFFTest(){
		///www->Dispose() null
		/// AssetBundle : 镜像 存储资源包
		/// LoadAsset :  加载内存 加载后的资源
		/// Instantiate： 实例化内存 实例化后的内存-》Destroy

		WWW www = new WWW (wwwPath);
		yield return www;	

		AssetBundle ab = www.assetBundle;
		GameObject go = ab.LoadAsset ("Cube") as GameObject;
		GameObject obj = GameObject.Instantiate (go);

		//false : 释放镜像内存、不释放加载内存
		//true 释放镜像内存，释放加载内存  尽然不用，使用则不能再使用了（不能再实例化） 慎重使用
		//ab.Unload (false);


		Resources.UnloadUnusedAssets ();
		//加载内存： 不被使用（引用的内存被释放）


		//GameObject newGo = GameObject.Instantiate (go);

	}

	*/

	/*	*/

	void Start(){
		StartCoroutine (EEETest ());
	}

	IEnumerator EEETest(){
		UnityWebRequest request = UnityWebRequest.GetAssetBundle (path4);

		yield return request.Send ();
		//获取包内容
		AssetBundle ab = DownloadHandlerAssetBundle.GetContent (request);

		//从包中获取具体内容
		GameObject go = ab.LoadAsset ("Cube") as GameObject;

		GameObject obj = Instantiate (go);

		WWW www = new WWW (pathMat4);
		yield return www;
		AssetBundle fAB = www.assetBundle;


		//FromFile
		//获取YoungAB 5.2版本可以用 WWW方式获取AB包www.assetBundle;
	//	AssetBundle fAB = AssetBundle.LoadFromFile (pathMat4);
		//获取YoungABManifest
		AssetBundleManifest mf = fAB.LoadAsset ("AssetBundleManifest") as AssetBundleManifest;
		//获取所有包的依赖

		string[] names2 = mf.GetAllDependencies ("newprefab");

	//	string[] names = mf.GetAllDependencies ("newprefab");
		for (int i = 0; i < names2.Length; i++) {
			Debug.Log (names2 [i]);
			Debug.Log (pathMat4);
			UnityWebRequest re = UnityWebRequest.GetAssetBundle (pathMat44 + names2 [i]);

			yield return re.Send ();
			Debug.Log ("errro?");

			AssetBundle getMatAB = DownloadHandlerAssetBundle.GetContent (re);
			Debug.Log ("???");
		}

	}

	//缓存形式
	/*
	void Start(){
		StartCoroutine (DDDTest ());
	}
	IEnumerator DDDTest(){

		  //如果本地存在，并且不需要更新，那么直接读取本地内容
		  //如果本地不存在、需要更新，那么读取服务器内容

		///wwwPath表示下载路径， 1 表示版本号,获得一次后就从本地获取了。
		/// 如果版本号一变，又要重新从服务器读取
		WWW www = WWW.LoadFromCacheOrDownload (wwwPath,2);
		yield return www;

		if (!string.IsNullOrEmpty (www.error)) {
			Debug.Log (www.error);
		}

		AssetBundle ab = www.assetBundle;
		GameObject go = ab.LoadAsset ("Sphere") as GameObject;
		GameObject obj = GameObject.Instantiate (go);

	}
	*/

	/*
	void Start(){
		StartCoroutine (WWWTest ());
	}

	IEnumerator WWWTest(){
		WWW www = new WWW (wwwPath);
		WWW wwwMat = new WWW (wwwMatPath);

		yield return www;

		if (!string.IsNullOrEmpty (www.error)) {
			Debug.Log (www.error);
		}
		//获取ab包
		AssetBundle ab = www.assetBundle;
		AssetBundle Mat = wwwMat.assetBundle;
		//从AB包中加载具体内容
		GameObject go = ab.LoadAsset ("Cube") as GameObject;
		GameObject obj = GameObject.Instantiate (go);
	}
	*/
	/*
	void Start(){
		StartCoroutine (BBB ());
	}

	IEnumerator BBB(){
		//从文件加载物体
		//必须是不压缩的格式  5.2s createFile
		AssetBundle.LoadFromFile (matPath);
		//从文件加载物体
		AssetBundle ab = AssetBundle.LoadFromFile (path);
		//加载资源
		GameObject go = ab.LoadAsset ("Cube") as GameObject;

		GameObject obj = GameObject.Instantiate (go);

		yield return null;
	}
	*/

	/*
	void Start() {
		StartCoroutine (AAA ());
	}


	IEnumerator AAA(){

		//获取请求ab包
		AssetBundle request = AssetBundle.LoadFromMemory (File.ReadAllBytes (paht));
		AssetBundle.LoadFromMemory(File.ReadAllBytes(path2));

		GameObject go = request.LoadAsset ("cube") as GameObject;

		GameObject obj = GameObject.Instantiate (go);

		yield return 0;
	
		object[] objs = request.LoadAllAssets ();

		for (int i = 0; i < objs.Length; i++) {
			GameObject go2 = objs[i] as GameObject;
			Debug.Log (objs [i]);
			GameObject obj2 = GameObject.Instantiate(go);
			obj2.transform.position = new Vector3 (i, 0, 0);
		}
	}
	
	*/
}
