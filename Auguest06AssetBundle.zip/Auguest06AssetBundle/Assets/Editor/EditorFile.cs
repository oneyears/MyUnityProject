﻿using UnityEditor;
using System.IO;

public class EditorFile{

	[MenuItem("扩展编辑器之创建AssetBundles/CreateAssetBundle")]
	private static void CreateAssetBundle(){
	//	UnityEngine.Debug.Log ("点击");

		string path = "MyAssetBundle";

		if (!Directory.Exists (path)) {
			Directory.CreateDirectory (path);
		}

		BuildPipeline.BuildAssetBundles (path, BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows64);

 	}

}
