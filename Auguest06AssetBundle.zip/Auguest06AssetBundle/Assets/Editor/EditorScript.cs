﻿using UnityEditor;
using System.IO;

public class EditorScript {
	//扩展编译器：给编译器添加菜单内容
	[MenuItem("Build/BuildAsset")]
	private static void BuildAsset(){

		UnityEngine.Debug.Log ("aaa");//编译状态操作


		//输出路径
		string path = "YoungAB";
		if (!Directory.Exists (path)) {
			Directory.CreateDirectory (path);//创建一个文件夹
		}

		//把指定好的属性的预制体制作成AB包
		BuildPipeline.BuildAssetBundles (path, BuildAssetBundleOptions.ChunkBasedCompression,
		BuildTarget.StandaloneWindows64);//电脑系统，需要对各个平台来设置
		//此时点击，读完条后，包就完成了

	}

}
